#include<iostream>
using namespace std;
class node{
    public:
    int data;
    node*left;
    node*right;
    node(int valve){
        data=valve;
        left=NULL;
        right=NULL;
    }
};
class bst{
    public:
    node*root;
    bst(){
        root=NULL;
    }
    void insertionsecond(node*nodetype,int data){
        if(root==NULL){
            root=new node(data);
            return;
        }
        node*temp=root;
        while(temp!=NULL){
            if(data<temp->data){
                if(temp->left)
                temp=temp->left;
                else{
                node*n=new node(data);
                temp->left=n;
                return;
            }
            }
            else if(data>temp->data){
                if(temp->right)
                temp=temp->right;
                else{
                    node*n=new node(data);
                    temp->right=n;
                    return;
                }
            }
            else{
                cout<<"Duplicate Found. ";
                return;
            }
        }
    }
    void insertion(node*nodetype,int data){
        if(root==NULL){
            root=new node(data);
            return;
        }
        if(data<root->data){
            if(!root->left){
            node*n=new node(data);
            root->left=n;
            return;
            }
            else{
                insertion(root->left,data);
            }
        }
        else if(data>root->data){
            if(!root->right){
                node*n=new node(data);
                root->right=n;
                return;
            }
            else{
                insertion(root->right,data);
            }
        }
        else{
            cout<<"Duplicate Found";
            return;
        }
    }
    void inorder(node*root){
        if(root==NULL){
            return;
        }
        cout<<root->data;
        inorder(root->left);
        inorder(root->right);
    }
    void sprint(node*test){
        if(test==NULL)
        return;
        else{
            // cout<<"hello";
            test->data;
        }
    }
    void search(node*root,int data){
        if(root->data==data){
            cout<<"Value Found";
            return;
        }
        if(data<root->data){
            search(root->left,data);
        }
        else if(data>root->data){
            search(root->right,data);
        }
        else{
            cout<<"Value Not Found";
            return;
        }
    }
};
int main(){
    bst obj1;
    obj1.insertionsecond(obj1.root,2);
    obj1.insertionsecond(obj1.root,5);
    obj1.insertionsecond(obj1.root,1);
    obj1.insertionsecond(obj1.root,14);
    obj1.search(obj1.root,16);
    // obj1.insertion(obj1.root,15);
    
    // obj1.insertion(obj1.root,16);
    cout<<endl;
    // obj1.sprint(obj1.root);
    obj1.inorder(obj1.root);
}