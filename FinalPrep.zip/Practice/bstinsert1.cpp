void insert (int val,node*temp){
    if(temp==NULL){
    node*n=new node(val);
    temp=n;}
    if(val==temp->data)
    return;
    if(val<temp->data){
        //insert (val,temp->left);
        if(temp->left!=NULL)
        insert(val,temp->left);
        else{
            node*n=new node(val);
            temp->left=n;
        }
    }
    if(val>temp->data){
        //insert(val,temp->right);
        if(temp->right!=NULL)
        insert(val,temp->left);
        else{
            node*n=new node(val);
            temp->left=n;
        }
    }
    int getLevel(node*ptr,int val,int level){
        if(ptr==NULL)
        return 0;
        if(ptr->info==val)
        return level;
        return getLevel(ptr->left,val,level+1)|
                getLevel(ptr->right,val,level+1);
    }
}