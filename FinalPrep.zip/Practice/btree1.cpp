#include<iostream>
using namespace std;
class node{
    public:
    int info;
    node*left;
    node*right;
    //node*parent;
    node(int val){
        info=val;
        left=NULL;
        right=NULL;
    }
};
node*parent(node*curr,node*p,node*par){
        if(curr==NULL)
        return NULL;
        if(curr==p){
            return par;
        }
        else{
            node*t=NULL;
            t=parent(curr->left,p,curr);
            if(t!=NULL)
            return t;
            else{
                t=parent(curr->right,p,curr);
                return t;
            }
        }
}
node* sibling(node*root,node*p){
    node*par=parent(root,p,NULL);
    if(par->left==p)
    return par->right;
    else
    return par->left;
}
void deleteTree(node*leaf){
    if(leaf!=NULL){
        deleteTree(leaf->left);
        deleteTree(leaf->right);
        delete leaf;
    }
}
void preOrder(node*n){
    if(n==NULL)
    return;
    cout<<n->info<<"\t";
    preOrder(n->left);
    preOrder(n->right);
}
void inOrder(node*n){
    if(n==NULL)
    return;
    inOrder(n->left);
    cout<<n->info<<"\t";
    inOrder(n->right);
}
void postOrder(node*n){
    if(n==NULL)
    return;
    postOrder(n->left);
    postOrder(n->right);
    cout<<n->info<<"\t";
}
int maxDepth(node*node){
    if(node==NULL)
    return -1;
    else{
        /*compute the depth of each subtree */
        int lDepth=maxDepth(node->left);
        int rDepth=maxDepth(node->right);

        //use the larger one 
        if(lDepth>rDepth)
        return (lDepth+1);

        else return (rDepth+1);

    }
}
void insert (int val,node*temp){
    if(temp==NULL){
    node*n=new node(val);
    temp=n;}
    if(val==temp->data)
    return;
    if(val<temp->data){
        //insert (val,temp->left);
        if(temp->left!=NULL)
        insert(val,temp->left);
        else{
            node*n=new node(val);
            temp->left=n;
        }
    }
    if(val>temp->data){
        //insert(val,temp->right);
        if(temp->right!=NULL)
        insert(val,temp->left);
        else{
            node*n=new node(val);
            temp->left=n;
        }
    }
    int getLevel(node*ptr,int val,int level){
        if(ptr==NULL)
        return 0;
        if(ptr->info==val)
        return level;
        return getLevel(ptr->left,val,level+1)|
                getLevel(ptr->right,val,level+1);
    }
}
int main(){
    node*root=new node(5);
    root->left=new node(2);
    root->right=new node(7);
    root->right->left=new node(3);
    root->right->right=new node(9);
    root->left->left=new node(6);
    root->left->left->right=new node(1);
    //printTree(root,NULL,false);

    //Find Parent
    node*n=parent(root,root->left->left,NULL);
    cout<<"Parent is: "<<n->info<<endl;
}