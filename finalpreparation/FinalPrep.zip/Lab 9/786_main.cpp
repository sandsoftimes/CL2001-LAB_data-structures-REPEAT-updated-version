#include<iostream>
using namespace std;
int main(){
    for(int i=0;i<5;i++)
    cout<<"786"<<endl;
}
